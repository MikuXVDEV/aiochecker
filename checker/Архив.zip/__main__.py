import asyncio
import logging
from loguru import logger
from checker import TOKEN
from aiogram import Dispatcher, Bot
from .routers import start, checker
from .utils.utils import InterceptHandler
from .middlewares.middlewares import Middleware

logging.basicConfig(handlers=[InterceptHandler()], level=0)


dp = Dispatcher()


async def main() -> None:
    bot = Bot(token=TOKEN)
    dp.include_routers(
        start.start_router,
        checker.checker_router)
    
    start.start_router.message.middleware(Middleware())
    checker.checker_router.message.middleware(Middleware())
    
    await dp.start_polling(bot)
    

asyncio.run(main())