import logging
from loguru import logger
from aiogram.types import Message
from aiogram.exceptions import TelegramBadRequest 
from checker import CHANNEL_ID
from aiogram import Bot


class InterceptHandler(logging.Handler):
    def emit(self, record):
        # Get corresponding Loguru level if it exists.
        try:
            level = logger.level(record.levelname).name
        except ValueError:
            level = record.levelname

        # Find caller from where originated the logged message.
        frame, depth = logging.currentframe(), 2
        while frame.f_code.co_filename == logging.__file__:
            frame = frame.f_back
            depth += 1

        logger.opt(depth=depth, exception=record.exc_info).log(level, record.getMessage())
        # гпт писал


async def formatted_from_mention(message: Message) -> None:
    return f"<a href='tg://user?id=6506201559'>‌{message.from_user.first_name}</a>"


async def check_user_in_channel(message: Message, bot: Bot) -> bool:
    status_user = None
    try:
        status_user = await bot.get_chat_member(chat_id=CHANNEL_ID, user_id=message.from_user.id)
        
        if status_user.status in ('left'):
            await message.answer("🤷‍♀️ | Вам нужно снова зайти в канал, прежде чем, что-либо писать в чат.")
            return
        
    except TelegramBadRequest:
        await message.answer(f"👋 | \nПодпишись на канал, прежде чем, что-либо писать!")
        return