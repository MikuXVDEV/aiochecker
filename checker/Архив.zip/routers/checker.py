from aiogram import Router, Bot, F
from aiogram.types import Message

from aiogram.enums import ChatType

checker_router = Router()

@checker_router.message(F.chat.type == ChatType.SUPERGROUP or ChatType.GROUP)
async def checker_subscription(
    message: Message,
    user: dict
    ) -> None:
    
    await message.delete()
    
    await message.answer("Гандон ебучий, в канал сначала зайди")
    
    # реализация черека сделана в middlewares.py.
    # Этот обработчик, просто принимает текст.