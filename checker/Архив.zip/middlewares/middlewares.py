from aiogram import BaseMiddleware, Bot
from aiogram.types import Message
from typing import Callable, Dict, Awaitable, Any
from ..utils.utils import formatted_from_mention, check_user_in_channel
from dataclasses import dataclass
from checker import CHANNEL_ID


@dataclass
class User:
    mention: str
    is_channel: bool
    channel_link: str

class Middleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: Dict[str, Any]
    ):
                
        is_channel =  await check_user_in_channel(event, data['bot'])
        mention = await formatted_from_mention(event)
        channel_link = await data['bot'].get_chat(CHANNEL_ID)

        data["user"] = User(
            mention=mention,
            is_channel=is_channel,
            channel_link=channel_link
            )
    
        await handler(event, data)

    
